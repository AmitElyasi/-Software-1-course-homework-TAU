package il.ac.tau.cs.sw1.ex7;

public abstract class AbstractTester {
	protected static void printErrorNum(int num){
		System.out.println("ERROR " + num);
	}
}
