package il.ac.tau.cs.sw1.riddle.d;

public class B {
	public static final int I = 2;

	private int i = 0;

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}
}
